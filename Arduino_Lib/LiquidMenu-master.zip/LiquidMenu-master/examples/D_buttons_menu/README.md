Example 4: buttons_menu
==================

![schematic](https://github.com/VasilKalchev/LiquidMenu/blob/master/examples/D_buttons_menu/buttons_menu.png?raw=true)
This example demonstrates how to use buttons, callback functions and changing text variables.
