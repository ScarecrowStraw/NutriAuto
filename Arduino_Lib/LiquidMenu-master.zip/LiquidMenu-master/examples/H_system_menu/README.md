Example 8: system_menu
==================

![schematic](https://github.com/VasilKalchev/LiquidMenu/blob/master/examples/H_system_menu/system_menu.png?raw=true)
This example demonstrates the how to build a menu system.
